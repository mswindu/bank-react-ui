package com.ftc.gc.hub.service;

import com.ftc.gc.hub.model.Payment;
import com.ftc.gc.hub.model.PaymentInfoFilter;
import com.ftc.gc.hub.model.Payment_;
import com.ftc.gc.hub.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
@Transactional
public class PaymentService {

    private final PaymentRepository paymentRepository;

    @Autowired
    PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public Page<Payment> findPayments(PaymentInfoFilter filter, Pageable pageRequest) {
        Specification<Payment> specification = Specification
                .where(SpecExpressions.equal(Payment_.bName, filter.getBName()))
                .and(paymentDateFrom(filter.getStartDate()))
                .and(paymentDateTo(filter.getEndDate()));

        return paymentRepository.findAll(specification, pageRequest);
    }

    private Specification<Payment> paymentDateFrom(Date paymentDate) {
        return (root, query, cb) -> cb.greaterThanOrEqualTo(root.get(Payment_.paymentDTime), paymentDate);
    }

    private Specification<Payment> paymentDateTo(Date paymentDate) {
        return (root, query, cb) -> cb.lessThan(root.get(Payment_.paymentDTime), paymentDate);
    }

//    private Specification<Payment> paymentDTimeBetween(Date paymentDTimeFrom, Date paymentDTimeTo) {
//        return (root, query, cb) -> cb.between(root.get(Payment_.paymentDTime), paymentDTimeFrom, paymentDTimeTo);
//    }

}
