package com.ftc.gc.hub.controller;

import org.apache.commons.lang3.StringUtils;
import com.ftc.gc.hub.model.Payment;
import com.ftc.gc.hub.model.PaymentInfoFilter;
import com.ftc.gc.hub.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.StringJoiner;

@RestController
@Slf4j
@RequestMapping(value = "/payments", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class PaymentController {
    private static final int MAX_PAGE_SIZE = 100;

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping
    @ResponseBody
    public ResponseEntity findPayments(
            PaymentInfoFilter paymentInfoFilter,
            @PageableDefault(size = 10) Pageable pageable
    ) {
        Page<Payment> paymentPage = paymentService.findPayments(
                paymentInfoFilter,
                convertPageable(pageable)
        );

        return new ResponseEntity<>(paymentPage.getContent(), formHeaders(paymentPage), HttpStatus.OK);
    }

    private HttpHeaders formHeaders(Page page) {
        HttpHeaders responseHeaders = new HttpHeaders();
        String link = formLinkForHeader(page);
        if (StringUtils.isNotEmpty(link)) {
            responseHeaders.set("Link", link);
        }
        responseHeaders.set("X-Total-Count", String.valueOf(page.getTotalElements()));
        responseHeaders.set("X-Total-Pages", String.valueOf(page.getTotalPages()));
        responseHeaders.set("X-Current-Page", String.valueOf(page.getNumber() + 1));
        responseHeaders.set("Access-Control-Allow-Origin", "*");
        responseHeaders.set("Access-Control-Expose-Headers", "X-Total-Count, X-Total-Pages, X-Current-Page");
        responseHeaders.setCacheControl("no-store, no-cache, must-revalidate");

        return responseHeaders;
    }

    private String formLinkForHeader(Page page) {
        StringJoiner joiner = new StringJoiner(",");

        if (!page.isFirst() && page.getNumber() != 1) {
            StringBuilder stringBuilder = new StringBuilder();
            String link = ServletUriComponentsBuilder.fromCurrentRequest()
                    .replaceQueryParam("page", 1)
                    .build()
                    .toUriString();
            joiner.add(stringBuilder.append('<').append(link).append(">; rel=\"first\"").toString());
        }
        if (page.hasPrevious()) {
            StringBuilder stringBuilder = new StringBuilder();
            String link = ServletUriComponentsBuilder.fromCurrentRequest()
                    .replaceQueryParam("page", page.previousPageable().getPageNumber()+1)
                    .build()
                    .toUriString();
            joiner.add(stringBuilder.append('<').append(link).append(">; rel=\"prev\"").toString());
        }
        if (page.hasNext()) {
            StringBuilder stringBuilder = new StringBuilder();
            String link = ServletUriComponentsBuilder.fromCurrentRequest()
                    .replaceQueryParam("page", page.nextPageable().getPageNumber()+1)
                    .build()
                    .toUriString();
            joiner.add(stringBuilder.append('<').append(link).append(">; rel=\"next\"").toString());
        }
        if (!page.isLast() && page.getNumber() != page.getTotalPages() - 2) {
            StringBuilder stringBuilder = new StringBuilder();
            String link = ServletUriComponentsBuilder.fromCurrentRequest()
                    .replaceQueryParam("page", page.getTotalPages())
                    .build()
                    .toUriString();
            joiner.add(stringBuilder.append('<').append(link).append(">; rel=\"last\"").toString());
        }

        return joiner.toString();
    }

    private static Pageable convertPageable(Pageable pageable) {
        return PageRequest.of(
                Math.max(pageable.getPageNumber() - 1, 0),
                Math.min(pageable.getPageSize(), MAX_PAGE_SIZE),
                pageable.getSort()
        );
    }

}
