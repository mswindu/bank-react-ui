package com.ftc.gc.hub.service;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.ObjectUtils;

import javax.persistence.metamodel.SingularAttribute;
import java.util.Collection;

/**
 * Обертка для самых распространненых предикатов.
 */
public class SpecExpressions {
    public static <T, S> Specification<T> equal(SingularAttribute<T, S> attribute, S value) {
        return ObjectUtils.isEmpty(value) ? null : (root, query, cb) -> cb.equal(root.get(attribute), value);
    }

    public static <T> Specification<T> upperCaseEqual(SingularAttribute<T, String> attribute, String value) {
        return ObjectUtils.isEmpty(value) ? null : (root, query, cb) ->
                cb.equal(cb.upper(root.get(attribute)), value.toUpperCase());
    }

    public static <T, S extends Number> Specification<T> numberFrom(SingularAttribute<T, S> attribute, S value) {
        return ObjectUtils.isEmpty(value) ? null : (root, query, cb) -> cb.ge(root.get(attribute), value);
    }

    public static <T, S extends Number> Specification<T> numberTo(SingularAttribute<T, S> attribute, S value) {
        return ObjectUtils.isEmpty(value) ? null : (root, query, cb) -> cb.lt(root.get(attribute), value);
    }

    public static <T, S> Specification<T> in(SingularAttribute<T, S> attribute, Collection<S> value) {
        return ObjectUtils.isEmpty(value) ? null : (root, query, cb) -> root.get(attribute).in(value);
    }

    public static <T> Specification<T> booleanEqual(SingularAttribute<T, String> attribute, Boolean value) {
        return ObjectUtils.isEmpty(value) ? null : (root, query, cb) -> cb.equal(root.get(attribute), value ? "Y" : "N");
    }
}
