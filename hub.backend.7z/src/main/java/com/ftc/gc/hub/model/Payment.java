package com.ftc.gc.hub.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;

@Data
@Entity
@Table(name = "HUB_PAYMENT_VW")
public class Payment {
    @Id
    @Column(name = "ID_PAYMENT", nullable = false, updatable = false)
    private Long idPayment;

    @Column(name = "BNAME")
    private String bName;

    @JsonFormat(pattern="dd.MM.yyyy hh:mm:ss")
    @Column(name = "PAYMENT_DTIME")
    private Date paymentDTime;

    @Column(name = "PCC_TERM_NAME")
    private String pccTermName;

    @Column(name = "PCC_SYSTEM_NAME")
    private String pccSystemName;

    @Column(name = "PCC_SYSTEM_DESCRIPTION")
    private String pccSystemDescription;

    @Column(name = "PCC_PAY_AMOUNT")
    private String pccPayAmount;

    @Column(name = "PCC_FINE_AMOUNT")
    private String pccFineAmount;

    @Column(name = "PCC_PAY_TYPE")
    private String pccPayType;

    @Column(name = "PCC_CURRENCY")
    private String pccCurrency;

    @JsonFormat(pattern="dd.MM.yyyy hh:mm:ss")
    @Column(name = "PCC_TERM_PAYMENT_DATE")
    private Date pccTermPaymentDate;

    @Column(name = "PCC_STATUS")
    private String pccStatus;

    @Column(name = "PCC_UTILITY_CODE")
    private String pccUtilityCode;

    @Column(name = "PCC_ERR_MSG")
    private String pccErrMsg;

    @Column(name = "PCC_ACCOUNT")
    private String pccAccount;

    @Column(name = "PCC_UNO")
    private String pccUno;

    @Column(name = "PCC_ID_TERM_PAY")
    private String pccIdTermPay;

    @Column(name = "PCC_ID_EXT_PAY")
    private String pccIdExtPay;

    @Column(name = "NODE_TERM_NAME")
    private String nodeTermName;

    @Column(name = "NODE_PAN")
    private String nodePan;

    @Column(name = "NODE_PAY_TYPE")
    private String nodePayType;

    @Column(name = "NODE_PAY_AMOUNT")
    private String nodePayAmount;

    @Column(name = "NODE_CURRENCY")
    private String nodeCurrency;

    @Column(name = "NODE_RRN")
    private String nodeRrn;

    @Column(name = "NODE_SID")
    private String nodeSid;

    @Column(name = "NODE_UNO")
    private String nodeUno;

    @JsonFormat(pattern="dd.MM.yyyy hh:mm:ss")
    @Column(name = "NODE_DTIME")
    private Date nodeDtime;
}
