package com.ftc.gc.hub.model;

import lombok.Data;

import java.util.Date;

@Data
public class PaymentInfo {
    private Date startDate;
    private Date endDate;
}
