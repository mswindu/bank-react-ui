const path = require('path')
const VuetifyLoaderPlugin = require('vuetify-loader/lib/plugin')

// https://cli.vuejs.org/ru/config/#vue-config-js
module.exports = {
  lintOnSave: process.env.NODE_ENV !== 'production',
  devServer: {
    port: 8000,
    proxy: {
      '/api': {
        target: process.env.API_BASE_URL,
        ws: false,
        changeOrigin: false
      }
    }
  },
  productionSourceMap: false,
  pages: {
    index: {
      // Точка входа для страницы
      entry: 'src/main.js',
      // Исходный шаблон
      template: 'index.html',
      // В результате будет dist/index.html
      filename: 'index.html',
      // Все фрагменты, добавляемые на этой странице, по умолчанию
      // Это извлеченные общий фрагмент и вендорный фрагмент.
      chunks: ['chunk-vendors', 'chunk-common', 'index']
    }
  },
  chainWebpack: webpackConfig => {
    // Прописываем алиасы для удобной навигации кода
    webpackConfig.resolve.alias
      .set('@api', path.resolve('src/api'))
      .set('@components', path.resolve('src/components'))
      .set('@pages', path.resolve('src/pages'))
      .set('@utils', path.resolve('src/utils'))

    // Загрузчик Vuetify компонентов. Будут добавлены в итоговую сборку только используемые компоненты
    webpackConfig
      .plugin('VuetifyLoaderPlugin')
      .use(VuetifyLoaderPlugin)

    if (process.env.NODE_ENV !== 'production' && process.env.NODE_ENV !== 'test') {
      webpackConfig
        .devtool('#eval-source-map')
    }
  }
}
