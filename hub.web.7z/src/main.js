// Внешние компоненты
import Vue from 'vue'
import VueRouter from 'vue-router'
import Vuetify from 'vuetify/lib'

import 'vuetify/src/stylus/app.styl'

// Внутренние компоненты
import App from './App.vue'
import store from './store'
import routes from './routes/routes'

// Локализация
import ru from 'vuetify/es5/locale/ru'

Vue.use(VueRouter)
Vue.use(Vuetify, {
  theme: {
    primary: '#343c48',
    secondary: '#448aff',
    accent: '#82B1FF',
    error: '#d62c41',
    info: '#2196F3',
    success: '#61b703',
    warning: '#ff8f00'
  },
  lang: {
    locales: { 'ru': ru },
    current: 'ru'
  }
})

// Конфигурация маршрутизатора
const router = new VueRouter({
  routes
})

new Vue({ // eslint-disable-line no-new
  el: '#app',
  store,
  router,
  render: a => a(App)
})
