<template>
  <VApp
    id="inspire"
    class="app"
  >
    <AppNavigation class="app--drawer" />
    <AppToolbar class="app--toolbar" />
    <VContent>
      <div class="page-wrapper">
        <RouterView />
      </div>
      <VFooter
        height="auto"
        class="white pa-3 app--footer"
      >
        <span class="caption">
          Design &copy; {{ new Date().getFullYear() }}
        </span>
        <VSpacer />
        <span class="caption mr-1">
          Make With Love
        </span>
        <VIcon
          color="pink"
          small
        >
          favorite
        </VIcon>
      </VFooter>
    </VContent>
  </VApp>
</template>

<script>
  import AppNavigation from '@components/AppNavigation.vue'
  import AppToolbar from '@components/AppToolbar.vue'
  export default {
    components: {
      AppNavigation,
      AppToolbar
    }
  }
</script>

<style lang="stylus" scoped>
  .page-wrapper
    min-height:calc(100vh - 64px - 50px);
</style>
