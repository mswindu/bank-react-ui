<template>
  <VContainer class="fluid fill-height">
    <VLayout>
      <VFlex class="xs-12">
        <VExpansionPanel class="mb-3 elevation-1">
          <VExpansionPanelContent lazy>
            <VLayout slot="header">
              <VIcon small color="#68a0fd" class="mr-2">
                mdi-filter
              </VIcon>
              <h2>Параметры поиска</h2>
            </VLayout>
            <VCard tile flat>
              <VLayout wrap>
                <VFlex xs2 class="pa-4">
                  <VMenu
                    ref="dateFrom"
                    v-model="pickerDateFrom"
                    :close-on-content-click="false"
                    :nudge-right="40"
                    :return-value.sync="dateFrom"
                    lazy
                    transition="scale-transition"
                    offset-y
                    full-width
                    width="290px"
                  >
                    <VTextField
                      slot="activator"
                      v-model="dateFrom"
                      label="Начало периода"
                      prepend-icon="event"
                      readonly
                    />
                    <VDatePicker v-model="dateFrom" scrollable no-title first-day-of-week="1" locale="ru-RU">
                      <VSpacer />
                      <VBtn flat color="primary" @click="pickerDateFrom = false">
                        Отменить
                      </VBtn>
                      <VBtn flat color="primary" @click="$refs.dateFrom.save(dateFrom)">
                        Применить
                      </VBtn>
                    </VDatePicker>
                  </VMenu>
                </VFlex>
                <VFlex xs2 class="pa-4">
                  <VMenu
                    ref="dateTo"
                    v-model="pickerDateTo"
                    :close-on-content-click="false"
                    :nudge-right="40"
                    :return-value.sync="dateTo"
                    persistent
                    lazy
                    transition="scale-transition"
                    offset-y
                    full-width
                    width="290px"
                  >
                    <VTextField
                      slot="activator"
                      v-model="dateTo"
                      label="Конец периода"
                      prepend-icon="event"
                      readonly
                    />
                    <VDatePicker v-model="dateTo" scrollable no-title first-day-of-week="1" locale="ru-RU">
                      <VSpacer />
                      <VBtn flat color="primary" @click="pickerDateTo = false">
                        Отменить
                      </VBtn>
                      <VBtn flat color="primary" @click="$refs.dateTo.save(dateTo)">
                        Применить
                      </VBtn>
                    </VDatePicker>
                  </VMenu>
                </VFlex>
                <VFlex xs2 d-flex class="pa-4">
                  <VSelect
                    ref="tSelect"
                    v-model="selectBank"
                    :items="selectBanks"
                    :rules="[v => !!v || 'Обязательно']"
                    label="Банк*"
                    required
                    item-text="nombre"
                  />
                </VFlex>
                <VFlex xs2 d-flex class="pa-4">
                  <VSelect
                    v-model="selectSystemName"
                    :items="selectSystemNames"
                    label="Система"
                    item-text="nombre"
                  />
                </VFlex>
              </VLayout>
              <VCardActions>
                <VBtn
                  :disabled="!valid"
                  round
                  outline
                  color="primary"
                  @click="submit"
                >
                  Применить
                </VBtn>
              </VCardActions>
            </VCard>
          </VExpansionPanelContent>
        </VExpansionPanel>

        <VDialog v-model="dialog" max-width="600px">
          <VCard>
            <VCardTitle>
              <span class="headline">
                {{ formTitle }}
              </span>
            </VCardTitle>

            <VDataIterator
              row
              wrap
              :items="paymentData"
              :hide-actions="true"
            >
              <VFlex
                v-if="props.item.notificationLevel === 'ERROR' || props.item.notificationLevel === 'WARNING'"
                slot="item"
                slot-scope="props"
                xs12
                md6
              >
                <VSubheader> {{ props.item.title }}</VSubheader>
                <VCardText>
                  <VTextField v-if="props.item.isPccUiShowData === '1'" v-model="props.item.pccValue" readonly label="ЦУП" />
                  <VTextField v-if="props.item.isNodeUiShowData === '1'" v-model="props.item.nodeValue" readonly label="Узел" />
                  <VTextField v-if="props.item.isAggregatorUiShowData === '1'" v-model="props.item.aggregatorValue" readonly label="Агрегатор" />
                </VCardText>
              </VFlex>
            </VDataIterator>

            <VDivider />

            <VCardActions>
              <VSpacer />
              <VBtn color="blue darken-1" flat @click="closeDialog">
                Закрыть
              </VBtn>
            </VCardActions>
          </VCard>
        </VDialog>

        <VCard>
          <VCardTitle>
            <VSpacer />
            <VTextField
              v-model="search"
              append-icon="search"
              label="Поиск по [УНО, Номеру услуги, term-pay-id, ext-pay-id]"
              single-line
              hide-details
            />
          </VCardTitle>
          <VDataTable
            :headers="headers"
            :items="payments"
            :pagination.sync="pagination"
            :total-items="totalItems"
            :loading="loading"
            :rows-per-page-items="rowsPerPageItems"
            class="elevation-1"
          >
            <template
              slot="items"
              slot-scope="props"
            >
              <tr :class="[props.item.isError === '1' ? 'error' : props.item.isWarning === '1' ? 'warning' : null]">
                <td class="text-xs-left">
                  {{ props.item.paymentDTime }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.termName }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.paymentAmount }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.paymentType }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.paymentCurrency }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.paymentStatusInPcc }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.utilityCode }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.errMsg }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.account }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.uno }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.idTermPay }}
                </td>
                <td class="text-xs-left">
                  {{ props.item.idExtPay }}
                </td>
                <td class="justify-center layout px-0">
                  <VIcon
                    v-if="props.item.isError === '1' || props.item.isWarning === '1'"
                    color="#68a0fd"
                    class="mr-2"
                    @click="viewDetail(props.item.idPayment)"
                  >
                    mdi-information
                  </VIcon>
                </td>
              </tr>
            </template>
            <template slot="no-data">
              <VAlert :value="true" color="error" icon="warning" outline>
                Ничего не найдено, измените, пожалуйста, параметры поиска
              </VAlert>
            </template>
          </VDataTable>
        </VCard>
      </VFlex>
    </VLayout>
  </VContainer>
</template>

<script>
  import debounce from 'lodash/debounce'

  import http from '@utils/http'

  export default {
    data () {
      return {
        search: null,

        dialog: false,
        viewDetailPaymentId: -1,
        paymentData: [],

        pickerDateFrom: false,
        dateFrom: null, // new Date().toISOString().substr(0, 10),
        pickerDateTo: false,
        /// dateTo: null, // new Date().toISOString().substr(0, 10),
        dateTo: new Date().toISOString().substr(0, 10),

        selectBank: null,
        selectBanks: ['', 'B001002', 'B001056', 'B001049', 'B000949'],

        selectSystemName: null,
        selectSystemNames: ['', 'FSG'],

        valid: true,

        totalItems: 0,
        payments: [],
        loading: true,
        pagination: {
          descending: false,
          sortBy: null,
          rowsPerPage: 10,
          page: 1
        },
        rowsPerPageItems: [
          5,
          10,
          25,
          50
        ],
        headers: [
          { text: 'Время платежа', align: 'left', sortable: true, value: 'paymentDTime' },
          { text: 'Терминал', align: 'left', sortable: false, value: 'termName' },
          { text: 'Сумма', align: 'left', sortable: false, value: 'paymentAmount' },
          { text: 'Тип платежа', align: 'left', sortable: false, value: 'paymentType' },
          { text: 'Валюта', align: 'left', sortable: false, value: 'paymentCurrency' },
          { text: 'Статус', align: 'left', sortable: false, value: 'paymentStatusInPcc' },
          { text: 'Номер услуги', align: 'left', sortable: false, value: 'utilityCode' },
          { text: 'Описание ошибки', align: 'left', sortable: false, value: 'errMsg' },
          { text: 'Счет', align: 'left', sortable: false, value: 'account' },
          { text: 'УНО', align: 'left', sortable: false, value: 'uno' },
          { text: 'term-pay-id', align: 'left', sortable: false, value: 'idTermPay' },
          { text: 'ext-pay-id', align: 'left', sortable: false, value: 'idExtPay' },
          { text: 'Действие', sortable: false, value: 'actionName' }
        ]
      }
    },
    computed: {
      formTitle () {
        return 'Детализация проблем платежа'
      }
    },
    watch: {
      pagination: {
        handler () {
          this.getPayments()
            .then(data => {
              this.payments = data.items
              this.totalItems = data.total
            })
        },
        deep: true
      },
      selectBank: {
        handler () {
          if (this.selectBank !== '') {
            this.valid = true
          } else {
            this.valid = false
          }
        }
      },
      dialog (val) {
        val || this.closeDialog()
      },
      search: function (newSearch, OldSearch) {
        this.debouncedGetPayments()
      }
    },
    created: function () {
      this.debouncedGetPayments = debounce(
        function handler () {
          this.getPayments()
            .then(data => {
              this.payments = data.items
              this.totalItems = data.total
            })
        }
        , 500
      )
    },
    methods: {
      getPayments () {
        if (this.dateFrom === null || this.dateTo === null || this.selectBank === null) {
          this.loading = false
          return new Promise((resolve, reject) => {
            let items = []
            let total = 0
            resolve({ items, total })
          })
        }

        this.loading = true

        return new Promise((resolve, reject) => {
          let items = []
          let total = 0
          http.get(
            '/api/payments',
            { params:
              {
                search: this.search ? this.search : null,
                startDate: this.dateFormat(this.dateFrom),
                endDate: this.dateFormat(this.dateTo),
                bName: this.selectBank,
                systemName: this.selectSystemName ? this.selectSystemName : '',
                page: this.pagination.page,
                size: this.pagination.rowsPerPage,
                sort: this.pagination.sortBy ? this.pagination.sortBy + ',' + (this.pagination.descending ? 'desc' : 'asc') : null
              }
            }
          )
            .then(res => {
              items = res.data
              total = parseInt(res.headers['x-total-count'])
              this.loading = false
              resolve({ items, total })
            })
            .catch(err => {
              console.log(err)
            })
            .finally(() => {
              this.loading = false
            })
        })
      },
      getPaymentData (paymentId) {
        return new Promise((resolve, reject) => {
          let items = []
          http.get('/api/payments/' + paymentId)
            .then(res => {
              items = res.data
              resolve({ items })
            })
            .catch(err => {
              console.log(err)
            })
            .finally(() => {
              this.loading = false
            })
        })
      },
      dateFormat (date) {
        if (!date) return null

        const [year, month, day] = date.split('-')

        return `${day.padStart(2, '0')}-${month.padStart(2, '0')}-${year}`
      },
      submit () {
        if (this.$refs.tSelect.validate()) {
          this.getPayments()
            .then(data => {
              this.payments = data.items
              this.totalItems = data.total
            })
        } else {
          this.valid = false
        }
      },
      viewDetail (paymentId) {
        this.viewDetailPaymentId = paymentId

        this.getPaymentData(paymentId)
          .then(data => {
            this.paymentData = data.items
          })

        this.dialog = true
      },
      closeDialog () {
        this.dialog = false
        setTimeout(() => {
          this.viewDetailPaymentId = -1
        }, 300)
      }
    }
  }
</script>
