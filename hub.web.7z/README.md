## WEB-интерфейс для проекта ХАБа
#

Описание проекта - https://virgo.ftc.ru/pages/viewpage.action?pageId=923991650
<br>WEB-интерфейс реализован на основе библиотеки [Vue](https://vuejs.org/).
<br>Верстка выполнена в стиле Material Design используя библиотку [Vuetify](https://vuetifyjs.com/).

### Настройки Visual Studio Code
Необходимо устновить следующие плагины:
```
Vetur - 0.14.3
```
#

### Сборка
Для сборки необходим [Yarn](https://yarnpkg.com/lang/en/).
<br>Для установки потребуется права администратора.
<br> В папке C:/Users/{user_name}/ необходимо изменить/создать следующий файлы с настройками:

.yarnrc
```
registry "https://registry.npmjs.org/"
email {Ваш email}
https-proxy "http://{Ваше сетевое имя}:{пароль}@proxy.ftc.ru:3128"
proxy "http://{Ваше сетевое имя}:{пароль}@proxy.ftc.ru:3128"
username {Ваше сетевое имя}
strict-ssl false
```

.npmrc
```
proxy=http://{Ваше сетевое имя}:{пароль}@proxy.ftc.ru:3128
https-proxy=http://{Ваше сетевое имя}:{пароль}@proxy.ftc.ru:3128
strict-ssl=false
```

.vuerc
```
{
  "useTaobaoRegistry": false,
  "packageManager": "yarn"
}
```
#

### Установка переменных окружения разработческого режима
Необходимо скопировать содержимое файла .env.example и поместить в файл .env.local, который надо будет создать.
<br>Описание переменных окружения:
```
API_BASE_URL - URL на котором находится средний слой проекта
```

#

## Установка проекта и его обновление
```
yarn install
```

### Запуск локального сервера в режиме горячей перезагрузки
```
yarn start
```

### Компиляция Production версии
```
yarn build
```

### Автоформатирование и проверка синтаксиса исходных кодов
```
yarn lint
```

### Настройка для отладки исходного кода в VS Code
Документация: https://ru.vuejs.org/v2/cookbook/debugging-in-vscode.html
```
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "chrome",
      "request": "launch",
      "name": "vuejs: chrome",
      "url": "http://localhost:8000",
      "webRoot": "${workspaceFolder}/src",
      "breakOnLoad": true,
      "sourceMapPathOverrides": {
        "webpack:///src/*": "${webRoot}/*"
      }
    },
    {
      "type": "firefox",
      "request": "launch",
      "name": "vuejs: firefox",
      "url": "http://localhost:8000",
      "webRoot": "${workspaceFolder}/src",
      "pathMappings": [{ "url": "webpack:///src/", "path": "${webRoot}/" }]
    }
  ]
}
```