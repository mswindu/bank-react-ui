<template>
  <v-card class="pa-4">
    <v-toolbar flat card>
      <v-flex xs2 class="pa-4">
        <v-dialog
          ref="dateFrom"
          v-model="pickerDateFrom"
          :return-value.sync="dateFrom"
          persistent
          lazy
          full-width
          width="290px"
        >
          <v-text-field
            slot="activator"
            v-model="dateFrom"
            label="Дата с:"
            prepend-icon="event"
            readonly
          />
          <v-date-picker v-model="dateFrom" scrollable>
            <v-spacer />
            <v-btn flat color="primary" @click="modal = false">Cancel</v-btn>
            <v-btn flat color="primary" @click="$refs.dateFrom.save(dateFrom)">OK</v-btn>
          </v-date-picker>
        </v-dialog>
      </v-flex>
      <v-flex xs2 class="pa-4">
        <v-dialog
          ref="dateTo"
          v-model="pickerDateTo"
          :return-value.sync="dateTo"
          persistent
          lazy
          full-width
          width="290px"
        >
          <v-text-field
            slot="activator"
            v-model="dateTo"
            label="Дата по:"
            prepend-icon="event"
            readonly
          />
          <v-date-picker v-model="dateTo" scrollable>
            <v-spacer />
            <v-btn flat color="primary" @click="modal = false">Cancel</v-btn>
            <v-btn flat color="primary" @click="$refs.dateTo.save(dateTo)">OK</v-btn>
          </v-date-picker>
        </v-dialog>
      </v-flex>
      <v-flex xs2 d-flex class="pa-4">
        <v-select
          ref="tSelect"
          v-model="selectBank"
          :items="selectBanks"
          :rules="[v => !!v || 'Обязательно']"
          label="Банк*"
          required
          item-text="nombre"
        />
      </v-flex>
      <v-btn
        :disabled="!valid"
        color="primary"
        @click="submit"
      >
        Применить
      </v-btn>
    </v-toolbar>
    <v-data-table
      :headers="headers"
      :items="payments"
      :pagination.sync="pagination"
      :total-items="totalItems"
      :loading="loading"
      :rows-per-page-items="rowsPerPageItems"
      class="elevation-1"
    >
      <template
        slot="items"
        slot-scope="props"
      >
        <td class="text-xs-left">{{ props.item.idPayment }}</td>
        <td class="text-xs-left">{{ props.item.paymentDTime }}</td>
        <td class="text-xs-left">{{ props.item.pccTermName }}</td>
        <td class="text-xs-left">{{ props.item.pccSystemDescription }}</td>
        <td class="text-xs-left">{{ props.item.pccPayAmount }}</td>
        <td class="text-xs-left">{{ props.item.pccFineAmount }}</td>
        <td class="text-xs-left">{{ props.item.pccPayType }}</td>
        <td class="text-xs-left">{{ props.item.pccCurrency }}</td>
        <td class="text-xs-left">{{ props.item.pccUtilityCode }}</td>
        <td class="text-xs-left">{{ props.item.pccErrMsg }}</td>
        <td class="text-xs-left">{{ props.item.pccAccount }}</td>
        <td class="text-xs-left">{{ props.item.pccUno }}</td>
        <td class="text-xs-left">{{ props.item.pccIdTermPay }}</td>
        <td class="text-xs-left">{{ props.item.pccIdExtPay }}</td>
        <td class="text-xs-left">{{ props.item.nodeTermName }}</td>
        <td class="text-xs-left">{{ props.item.nodePan }}</td>
        <td class="text-xs-left">{{ props.item.nodePayType }}</td>
        <td class="text-xs-left">{{ props.item.nodePayAmount }}</td>
        <td class="text-xs-left">{{ props.item.nodeCurrency }}</td>
        <td class="text-xs-left">{{ props.item.nodeRrn }}</td>
        <td class="text-xs-left">{{ props.item.nodeSid }}</td>
        <td class="text-xs-left">{{ props.item.nodeUno }}</td>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
  import axios from 'axios'

  export default {
    data () {
      return {
        pickerDateFrom: false,
        dateFrom: new Date().toISOString().substr(0, 10),
        pickerDateTo: false,
        dateTo: new Date().toISOString().substr(0, 10),

        selectBank: null,
        selectBanks: ['', 'B001056', 'B001049', 'B000949'],

        valid: true,

        totalItems: 0,
        payments: [],
        loading: true,
        pagination: {
          descending: false,
          sortBy: null,
          rowsPerPage: 10,
          page: 1
        },
        rowsPerPageItems: [
          5,
          10,
          25,
          50
        ],
        headers: [
          { text: 'Payment Id', align: 'left', sortable: true, value: 'idPayment' },
          { text: 'Время платежа', align: 'left', sortable: false, value: 'paymentDTime' },
          { text: 'Терминал', align: 'left', sortable: false, value: 'pccTermName' },
          { text: 'Система', align: 'left', sortable: false, value: 'pccSystemDescription' },
          { text: 'Количество в ЦУПе', align: 'left', sortable: false, value: 'pccPayAmount' },
          { text: 'Комиссия в ЦУПе', align: 'left', sortable: false, value: 'pccFineAmount' },
          { text: 'Тип платежа', align: 'left', sortable: false, value: 'pccPayType' },
          { text: 'Валюта', align: 'left', sortable: false, value: 'pccCurrency' },
          { text: 'Номер услуги', align: 'left', sortable: false, value: 'pccUtilityCode' },
          { text: 'Описание ошибки', align: 'left', sortable: false, value: 'pccErrMsg' },
          { text: 'Счет', align: 'left', sortable: false, value: 'pccAccount' },
          { text: 'УНО', align: 'left', sortable: false, value: 'pccUno' },
          { text: 'term-pay-id', align: 'left', sortable: false, value: 'pccIdTermPay' },
          { text: 'ext-pay-id', align: 'left', sortable: false, value: 'pccIdExtPay' },
          { text: 'Терминал в узле', align: 'left', sortable: false, value: 'nodeTermName' },
          { text: 'ПАН', align: 'left', sortable: false, value: 'nodePan' },
          { text: 'Тип платежа', align: 'left', sortable: false, value: 'nodePayType' },
          { text: 'Сумма платежа', align: 'left', sortable: false, value: 'nodePayAmount' },
          { text: 'Валюта', align: 'left', sortable: false, value: 'nodeCurrency' },
          { text: 'RRN', align: 'left', sortable: false, value: 'nodeRrn' },
          { text: 'SID', align: 'left', sortable: false, value: 'nodeSid' },
          { text: 'UNO', align: 'left', sortable: false, value: 'nodeUno' }
        ]
      }
    },
    watch: {
      pagination: {
        handler () {
          this.getDataFromApi()
            .then(data => {
              this.payments = data.items
              this.totalItems = data.total
            })
        },
        deep: true
      },
      selectBank: {
        handler () {
          if (this.selectBank !== '') {
            this.valid = true
          } else {
            this.valid = false
          }
        }
      }
    },
    methods: {
      getDataFromApi () {
        this.loading = true
        return new Promise((resolve, reject) => {
          let items = []
          let total = 0
          axios.get(
            'http://localhost:9000/payments',
            { params:
              {
                startDate: this.dateFormat(this.dateFrom),
                endDate: this.dateFormat(this.dateTo),
                bName: this.selectBank,
                page: this.pagination.page,
                size: this.pagination.rowsPerPage,
                sort: this.pagination.sortBy ? this.pagination.sortBy + ',' + (this.pagination.descending ? 'desc' : 'asc') : null
              }
            }
          )
            .then(res => {
              items = res.data
              total = parseInt(res.headers['x-total-count'])
              this.loading = false
              resolve({ items, total })
            })
            .catch(err => {
              console.log(err)
            })
        })
      },
      dateFormat (date) {
        if (!date) return null

        const [year, month, day] = date.split('-')

        return `${day.padStart(2, '0')}-${month.padStart(2, '0')}-${year}`
      },
      submit () {
        if (this.$refs.tSelect.validate()) {
          this.getDataFromApi()
            .then(data => {
              this.payments = data.items
              this.totalItems = data.total
            })
        } else {
          this.valid = false
        }
      }
    }
  }
</script>
