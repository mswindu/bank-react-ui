const Menu = [
  {
    title: 'Dashboard',
    group: 'apps',
    icon: 'dashboard',
    name: 'Dashboard'
  },
  {
    title: 'Media',
    group: 'apps',
    name: 'Media',
    icon: 'perm_media'
  }
]

export default Menu
