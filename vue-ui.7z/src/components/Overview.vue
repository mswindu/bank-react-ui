<template>
  <div class="content">
    <b-table striped hover v-model="tableValues" :items="items" :fields="fields">
      <template slot="HEAD_show_checkbox" slot-scope="head">
        <!--<b-form-checkbox @click.stop="toggleSelected" v-model="allSelected"></b-form-checkbox>-->
        <!--<input type="checkbox" @click.stop="toggleSelected" v-model="allSelected">-->
        <b-checkbox @click.stop="toggleSelected" v-model="allSelected"></b-checkbox>
      </template>
      <template slot="show_checkbox" slot-scope="row">
        <b-checkbox name="checked" :key="row.index" :value="row.item" @click.stop v-model="selected"></b-checkbox>
      </template>      
    </b-table>

    <div class="my-1">
      all Selected:
      <br>
      <pre>{{ allSelected }}</pre>
    </div>

    <div class="my-1">
      Checked Items:
      <br>
      <pre>{{ JSON.stringify(selected, null, '  ') }}</pre>
    </div>
  </div>
</template>

<script>
const items = [
        { age: 40, first_name: 'Dickerson', last_name: 'Macdonald', address: { country: 'USA', city: 'New York' } },
        { age: 21, first_name: 'Larsen', last_name: 'Shaw', address: { country: 'Canada', city: 'Toronto' }},
        { age: 89, first_name: 'Geneva', last_name: 'Wilson', address: { country: 'Australia', city: 'Sydney' } },
        { age: 38, first_name: 'Jami', last_name: 'Carney', address: { country: 'England', city: 'London' } },
        { age: 27, first_name: 'Nikita', last_name: 'Murzin', address: { country: 'Russia', city: 'Novosibirsk' } },
        { age: 27, first_name: 'Stanislav', last_name: 'Nilov', address: { country: 'Russia', city: 'Novosibirsk' } },
      ]

export default {  
  data () {
    return {
      selected: [],
      tableValues: [],
      allSelected: false,
      // Note 'isActive' is left out and will not appear in the rendered table 
      fields: {
        'show_checkbox' : { 
          label: ''
        },
        last_name: {
          label: 'Person last name',
          sortable: true
        },
        first_name: {
          label: 'Person first name',
          sortable: true
        },
        age: {
          label: 'Person age',
          sortable: false
        },
        city: {
          key: 'address.city',
          sortable: true
        },
        'address.country': {
          label: 'Country',
          sortable: true
        }
      },
      items: items
      
    }
  },
  watch: {
    selected(newVal, oldVal) {
      console.log('newVal: ' + JSON.stringify(newVal, null, '  '))
      console.log('oldVal: ' + JSON.stringify(oldVal, null, '  '))
      this.allSelected = (this.tableValues.length === newVal.length) ? true : false
    }
  },
  methods: {
    toggleSelected() {
      this.allSelected = !this.allSelected
      this.selected = this.allSelected ? this.tableValues : []
      console.log('toggleSelected' + this.selected)
    },
    clearSelected() {
      this.allSelected = false
      this.selected = []
      console.log('clearSelected' + this.selected)
    }
  }
}
</script>