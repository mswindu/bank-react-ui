package com.ftc.gc.hub.service;

import com.ftc.gc.hub.model.Discrepancy;
import com.ftc.gc.hub.repository.DiscrepancyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DiscrepancyService {

    private final DiscrepancyRepository discrepancyRepository;

    @Autowired
    public DiscrepancyService(DiscrepancyRepository discrepancyRepository) {
        this.discrepancyRepository = discrepancyRepository;
    }

    public List<Discrepancy> getDiscrepancy(Long idPayment) {
        return discrepancyRepository.findAllByIdFp(idPayment);
    }
}
