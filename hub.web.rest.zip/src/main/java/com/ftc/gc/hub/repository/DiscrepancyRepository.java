package com.ftc.gc.hub.repository;

import com.ftc.gc.hub.model.Discrepancy;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DiscrepancyRepository extends CrudRepository<Discrepancy, Long> {
    List<Discrepancy> findAllByIdFp(Long IdFp);
}
