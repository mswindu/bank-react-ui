package com.ftc.gc.hub.model;

import lombok.EqualsAndHashCode;

import java.io.Serializable;

@EqualsAndHashCode
public class DiscrepancyPrimaryKey implements Serializable {
    private Long idFp;
    private String compareType;
}