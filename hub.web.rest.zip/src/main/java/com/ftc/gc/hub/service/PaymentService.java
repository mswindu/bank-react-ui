package com.ftc.gc.hub.service;

import com.ftc.gc.hub.model.Payment;
import com.ftc.gc.hub.model.PaymentInfoFilter;
import com.ftc.gc.hub.repository.PaymentRepository;
import com.ftc.gc.hub.service.specification.PaymentSpecification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentSpecification paymentSpecification;

    @Autowired
    PaymentService(PaymentRepository paymentRepository, PaymentSpecification paymentSpecification) {
        this.paymentRepository = paymentRepository;
        this.paymentSpecification = paymentSpecification;
    }

    public Page<Payment> findPayments(PaymentInfoFilter filter, Pageable pageRequest) {
        return paymentRepository.findAll(paymentSpecification.getFilter(filter), pageRequest);
    }
}
