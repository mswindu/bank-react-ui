package com.ftc.gc.hub.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@IdClass(DiscrepancyPrimaryKey.class)
@Table(name = "HUB_DISCREPANCY_VW")
public class Discrepancy {
    @Id
    @Column(name = "ID_FP")
    private Long idFp;

    @Id
    @Column(name = "COMPARE_TYPE")
    private String compareType;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "NOTIFICATION_LEVEL")
    private String notificationLevel;

    @Column(name = "PCC_VALUE")
    private String pccValue;

    @Column(name = "NODE_VALUE")
    private String nodeValue;

    @Column(name = "AGGREGATOR_VALUE")
    private String aggregatorValue;

    @Column(name = "IS_PCC_UI_SHOW_DATA")
    private String isPccUiShowData;

    @Column(name = "IS_NODE_UI_SHOW_DATA")
    private String isNodeUiShowData;

    @Column(name = "IS_AGGREGATOR_UI_SHOW_DATA")
    private String isAggregatorUiShowData;
}
