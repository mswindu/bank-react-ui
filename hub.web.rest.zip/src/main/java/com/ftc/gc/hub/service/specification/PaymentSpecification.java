package com.ftc.gc.hub.service.specification;

import com.ftc.gc.hub.model.Payment;
import com.ftc.gc.hub.model.PaymentInfoFilter;
import com.ftc.gc.hub.model.Payment_;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import javax.persistence.metamodel.SingularAttribute;
import java.util.Date;

@Component
public class PaymentSpecification extends BaseSpecification<Payment, PaymentInfoFilter> {

    @Override
    public Specification<Payment> getFilter(PaymentInfoFilter filter) {
        return Specification
                .where(equal(Payment_.bName, filter.getBName()))
                .and(paymentDateFrom(filter.getStartDate()))
                .and(paymentDateTo(filter.getEndDate()))
                .and(systemName(filter.getSystemName()))
                .and(search(filter.getSearch()));
    }

    private Specification<Payment> paymentDateFrom(Date paymentDate) {
        return (root, query, cb) -> cb.greaterThanOrEqualTo(root.get(Payment_.paymentDTime), paymentDate);
    }

    private Specification<Payment> paymentDateTo(Date paymentDate) {
        return (root, query, cb) -> cb.lessThan(root.get(Payment_.paymentDTime), paymentDate);
    }

    private Specification<Payment> systemName(String systemName) {
        return (root, query, cb) ->
                ObjectUtils.isEmpty(systemName) ? cb.isNull(root.get(Payment_.systemName)) :
                        cb.equal(root.get(Payment_.systemName), systemName);
    }

    private Specification<Payment> search(String search) {
        return ObjectUtils.isEmpty(search) ? null : (root, query, cb) ->
                cb.or(
                        cb.like(cb.lower(root.get(Payment_.idTermPay)), containsLowerCase(search)),
                        cb.like(cb.lower(root.get(Payment_.idExtPay)), containsLowerCase(search)),
                        cb.like(cb.lower(root.get(Payment_.utilityCode)), containsLowerCase(search)),
                        cb.like(cb.lower(root.get(Payment_.uno)), containsLowerCase(search))
                );
    }

    private static <T, S> Specification<T> equal(SingularAttribute<T, S> attribute, S value) {
        return ObjectUtils.isEmpty(value) ? null : (root, query, cb) -> cb.equal(root.get(attribute), value);
    }
}
