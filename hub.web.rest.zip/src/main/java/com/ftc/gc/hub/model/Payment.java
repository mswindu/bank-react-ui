package com.ftc.gc.hub.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;

@Data
@Entity
@Table(name = "HUB_PAYMENT_VW")
public class Payment {
    @Id
    @Column(name = "ID_PAYMENT", nullable = false, updatable = false)
    private Long idPayment;

    @Column(name = "BNAME")
    private String bName;

    @JsonFormat(pattern = "dd.MM.yyyy hh:mm:ss")
    @Column(name = "PAYMENT_DTIME")
    private Date paymentDTime;

    @Column(name = "TERM_NAME")
    private String termName;

    @Column(name = "SYSTEM_NAME")
    private String systemName;

    @Column(name = "PAYMENT_AMOUNT")
    private String paymentAmount;

    @Column(name = "PAYMENT_TYPE")
    private String paymentType;

    @Column(name = "PAYMENT_CURRENCY")
    private String paymentCurrency;

    @Column(name = "PAYMENT_STATUS_IN_PCC")
    private String paymentStatusInPcc;

    @Column(name = "UTILITY_CODE")
    private String utilityCode;

    @Column(name = "ERR_MSG")
    private String errMsg;

    @Column(name = "ACCOUNT")
    private String account;

    @Column(name = "UNO")
    private String uno;

    @Column(name = "ID_TERM_PAY")
    private String idTermPay;

    @Column(name = "ID_EXT_PAY")
    private String idExtPay;

    @Column(name = "IS_ERROR")
    private String isError;

    @Column(name = "IS_WARNING")
    private String isWarning;
}
