package com.ftc.gc.hub.model;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
public class PaymentInfoFilter {
    @NotNull
    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private Date startDate;

    @NotNull
    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private Date endDate;

    @NotNull
    private String bName;

    private String systemName;

    private String search;
}
