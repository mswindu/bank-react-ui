## Средний слой для проекта ХАБа

Описание проекта - https://virgo.ftc.ru/pages/viewpage.action?pageId=923991650

### Настройки IDEA
Необходимо включить настройки:
```
Build, Execution, Deployment -> Compiler -> Annotation Processors
    -> Enable annotation processing
    -> Obtain processors from project classpath
```

### Сборка
Для сборки необходим [Gradle](https://gradle.org/).