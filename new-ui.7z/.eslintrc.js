module.exports = {
    plugins: ['vue'], // enable vue plugin
    extends: ['plugin:vue/essential', 'prettier'], // activate vue related rules
}