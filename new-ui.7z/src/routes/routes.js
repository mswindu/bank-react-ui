const NotFound = { template: '<div>NotFound</div>' }

import DashboardLayout  from '../components/DashboardLayout.vue'
import Overview         from '../components/Overview.vue'

const routes = [
  {
    path: '/',
    component: DashboardLayout,
    redirect: '/admin/overview'
  },
  {
    path: '/admin',
    component: DashboardLayout,
    redirect: '/admin/overview',
    children: [
      {
        path: 'overview',
        name: 'Overview',
        component: Overview
      }
    ]
  },
  {
    path: '*',
    component: NotFound
  }
]

export default routes