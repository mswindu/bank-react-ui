<template>
  <div class="content">
    <div>
      Банк: <b-form-select v-model="bNameSelected" :options="bNameOptions" class="mb-4" />
    </div>
    <b-form @submit="onSubmit">
      <b-form-input id="date1"
                    v-model="form.dateFrom"
                    required
                    placeholder="Enter date from">
      </b-form-input>
      <b-form-input id="date2"
                    v-model="form.dateTo"
                    required
                    placeholder="Enter date to">
      </b-form-input>
      <b-button type="submit" variant="primary">Submit</b-button>
    </b-form>
    <b-pagination size="md" :total-rows="totalRows" v-model="currentPage" :per-page="10"></b-pagination>
    <b-table striped bordered hover v-model="tableValues" :items="items" :fields="fields"></b-table>
  </div>
</template>

<script>
import axios from 'axios'

export default {  
  data () {
    return {
      currentPage: null,
      countPages: null,
      totalRows: null,
      tableValues: [],
      bNameSelected: null,
      bNameOptions: [
        { value: 'B001056', text: 'B001056' },
        { value: 'B001049', text: 'B001049' },
        { value: 'B000949', text: 'B000949' }
      ],
      fields: {
        idPayment: {
          label: 'Payment Id',
          sortable: false
        },
        paymentDTime: {
            label: 'Время платежа',
            sortable: false
        },
        pccTermName: {
            label: 'Терминал',
            sortable: false
        },
        pccSystemDescription: {
            label: 'Система',
            sortable: false
        },
        pccPayAmount: {
            label: 'Количество в ЦУПе',
            sortable: false
        },
        pccFineAmount: {
            label: 'Комиссия в ЦУПе',
            sortable: false
        },
        pccPayType: {
            label: 'Тип платежа',
            sortable: false
        },
        pccCurrency: {
            label: 'Валюта',
            sortable: false
        },
        pccUtilityCode: {
            label: 'Номер услуги',
            sortable: false
        },
        pccErrMsg: {
            label: 'Описание ошибки',
            sortable: false
        },
        pccAccount: {
            label: 'Счет',
            sortable: false
        },
        pccUno: {
            label: 'УНО',
            sortable: false
        },
        pccIdTermPay: {
            label: 'term-pay-id',
            sortable: false
        },
        pccIdExtPay: {
            label: 'ext-pay-id',
            sortable: false
        },
        nodeTermName: {
            label: 'Терминал в узле',
            sortable: false
        },
        nodePan: {
            label: 'ПАН',
            sortable: false
        },
        nodePayType: {
            label: 'Тип платежа',
            sortable: false
        },
        nodePayAmount: {
            label: 'Сумма платежа',
            sortable: false
        },
        nodeCurrency: {
            label: 'Валюта',
            sortable: false
        },
        nodeRrn: {
            label: 'RRN',
            sortable: false
        },
        nodeSid: {
            label: 'SID',
            sortable: false
        },
        nodeUno: {
            label: 'UNO',
            sortable: false
        },
      },
      items: [],
      form: {
        dateFrom: '01-10-2018',
        dateTo: '01-11-2018'
      }
    }
  },
  watch: {
    currentPage(newVal, oldVal) {
      if(oldVal != null && newVal != oldVal) {
        this.getPayments(newVal, this.bNameSelected)
      }
    }
  },
  methods: {
      getPayments(curPage, bName) {
        console.log("curPage = " + curPage + ", " + " bname = " + bName)
        if( curPage == null ) {
          this.currentPage = 1
        }
        if(bName == null) {
          return;
        }

        axios.get("http://localhost:9000/payments?startDate=" + this.form.dateFrom + "&endDate=" + this.form.dateTo + "&bName=" + bName + "&page=" + curPage)
          .then(response => {
              this.items = response.data
              this.currentPage = parseInt(response.headers["x-current-page"])
              this.totalRows = parseInt(response.headers["x-total-count"])
              console.log(response.headers);
              console.log(response);
          })
      },
      onSubmit (evt) {
        this.currentPage = 1
        this.getPayments(this.currentPage, this.bNameSelected)
      }
    }
}
</script>