<template>
  <div class="wrapper">
    <div class="main-panel">
      <top-navbar></top-navbar>
      <dashboard-content></dashboard-content>
      <footer-content></footer-content>
    </div>
  </div>
</template>
<script>
  import TopNavbar from './TopNavbar.vue'
  import DashboardContent from './Content.vue'
  import FooterContent from './Footer.vue'

  export default {
    components: {
      TopNavbar,
      DashboardContent,
      FooterContent
    }
  }
</script>
<style>
</style>